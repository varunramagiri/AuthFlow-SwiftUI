import SwiftUI

struct ContentView: View {
    @State private var username: String = ""
    @State private var password: String = ""
    @State private var storedUsername: String? = nil
    @State private var storedPassword: String? = nil
    @State private var showSignUp = false
    @State private var showWelcome = false
    @State private var errorMessage: String = ""
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Login")
                    .font(.largeTitle)
                    .padding(.bottom, 20)
                
                TextField("Username", text: $username)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(5.0)
                    .padding(.bottom, 20)
                
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(5.0)
                    .padding(.bottom, 20)
                
                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding(.bottom, 20)
                }
                
                Button(action: {
                    if username == storedUsername && password == storedPassword {
                        showWelcome = true
                    } else {
                        errorMessage = "Invalid username or password"
                    }
                }) {
                    Text("Login")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 220, height: 60)
                        .background(storedUsername == nil ? Color.gray : Color.blue)
                        .cornerRadius(15.0)
                }
                .disabled(storedUsername == nil)
                .padding(.bottom, 10)
                
                Button(action: {
                    showSignUp = true
                }) {
                    Text("Sign Up")
                        .font(.headline)
                        .foregroundColor(.blue)
                }
                .padding(.top, 20)
                
                // Navigation to Sign Up and Welcome
                NavigationLink(destination: SignUpView(storedUsername: $storedUsername, storedPassword: $storedPassword), isActive: $showSignUp) {
                    EmptyView()
                }
                NavigationLink(destination: WelcomeView(username: username), isActive: $showWelcome) {
                    EmptyView()
                }
            }
            .padding()
        }
    }
}

