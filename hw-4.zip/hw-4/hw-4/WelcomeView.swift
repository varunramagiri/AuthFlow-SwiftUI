//
//  WelcomeView.swift
//  hw-4
//
//  Created by Varun Ramagiri on 10/23/24.
//

import SwiftUI

struct WelcomeView: View {
    var username: String
    
    var body: some View {
        VStack {
            Text("Welcome, \(username)!")
                .font(.largeTitle)
                .padding()
        }
    }
}
