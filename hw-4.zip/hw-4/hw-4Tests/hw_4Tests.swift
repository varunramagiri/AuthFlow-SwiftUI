//
//  hw_4Tests.swift
//  hw-4Tests
//
//  Created by Varun Ramagiri on 10/23/24.
//

import Testing

struct hw_4Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
